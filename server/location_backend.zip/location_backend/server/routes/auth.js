const express = require("express");
const router = express.Router();
const axios = require('axios');

router.post('/directions', async (req, res) => {
  try {
    const { originLat, originLng, destination } = req.body;
    const apiKey = 'AIzaSyDlfKZpdUEuf6P-PZwr0aWRIfKc7GEVQbg';
    const response = await axios.get('https://maps.googleapis.com/maps/api/directions/json', {
      params: {
        origin: `${originLat},${originLng}`,
        destination,
        key: apiKey
      }
    });
    res.status(200).json(response.data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server Error' });
  }
});

module.exports = router;