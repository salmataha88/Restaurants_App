//server.js
const express = require("express");
const mongoose = require("mongoose");
const authRouter = require("./routes/auth");

const PORT = process.env.PORT || 3000;
const app = express();

app.use(express.json());
app.use(authRouter);

const DB = "mongodb://localhost:27017/resturants";
mongoose.connect(DB, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => {
  console.log("MongoDB connected");
}).catch((err) => {
  console.error("MongoDB connection error:", err);
  process.exit(1); // Exit the process on MongoDB connection error
});

// Define restaurant schema
const restaurantSchema = new mongoose.Schema({
  name: { type: String, required: true },
  location: { type: String, required: true },
  cuisine: { type: String, required: true }
});

// Apply the `useCreateIndex` option to the schema
restaurantSchema.set('useCreateIndex', true);

// Create restaurant model
const Restaurant = mongoose.model("Restaurant", restaurantSchema);

// Add a new route to create a new restaurant
app.post("/api/restaurants", async (req, res) => {
  try {
    const { name, location, cuisine } = req.body;
    const restaurant = new Restaurant({ name, location, cuisine });
    await restaurant.save();
    res.status(201).json(restaurant);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server Error" });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
