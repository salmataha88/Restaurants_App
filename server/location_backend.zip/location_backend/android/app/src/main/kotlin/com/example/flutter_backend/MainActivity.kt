package com.example.flutter_backend

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
