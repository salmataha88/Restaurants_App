import 'dart:convert';
import 'package:http/http.dart' as http;

Future<void> getDirections(
    double originLat, double originLng, String destination) async {
  try {
    final response = await http.post(
      Uri.parse('http://localhost:3000/api/directions/directions'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, dynamic>{
        'originLat': originLat,
        'originLng': originLng,
        'destination': destination,
      }),
    );
    if (response.statusCode == 200) {
      var directionsData = jsonDecode(response.body);
      print(directionsData);
    } else {
      print('Failed to load directions');
    }
  } catch (e) {
    print('Network error: $e');
  }
}

void main() {}
